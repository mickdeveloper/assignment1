import { useContext, useEffect, useState } from "react";
import { Link, useNavigate, useParams,  } from "react-router-dom";
import { Contextapi } from "./Contextapi";

function Profile() {
   const {name,setName}=useContext(Contextapi)
  

  const {id}=useParams()

   

    //const [name,setName]=useState('')
    const [place,setPlace]=useState('')
    const [age,setAge]=useState('')
    const [password,setPassword]=useState('')
    // const [userdata,setUserdata]=useState([])
    // const [message,setMessage]=useState('')
    const navigate=useNavigate()
    
    

    useEffect(()=>{


        
        fetch(`/api/singleuserdata/${id}`)
        
        },[])
    function handellogout(e){
        window.localStorage.removeItem('name')
        setName(window.localStorage.getItem('name'))
       navigate('/')
    }
    function handleform(e){
        e.preventDefault()
        const formdata={name,age,place,password}
        // console.log(formdata)
        // fetch(`/api/profileupdate/${id}`,{
        //     method:'PUT',
        //     headers:{"Content-Type":"application/json"},
        //     body:JSON.stringify(formdata)})
    }

    return ( 
        <>  
 <nav className="navbar navbar-expand-lg bg-dark">
  <div className="container-fluid">
    <Link className="navbar-brand" to="#"><span className="text-light">Welcome <b className="text-warning">{name}</b></span></Link>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div className="navbar-nav ms-auto">
      <Link className="nav-link active" aria-current="page" to="/home">Home</Link>
        <Link className="nav-link active" aria-current="page" to="/profile">Profile Update</Link>
        <Link className="nav-link active" aria-current="page" to="/location">Location</Link>
        
        <Link className="nav-link" to="/"><button className="btn btn-danger" onClick={(e)=>{handellogout(e)}}>Logout</button></Link>
       
       
      </div>
    </div>
  </div>
</nav>


         <section id="login">
        
<div className="row">
    <div className="col-md-4"></div>
<div className="col-md-4">

<form onSubmit={(e)=>{handleform(e)}}>
    <h2 className="text-center">Update Here</h2>
<label>name</label>
<input type="text" className="form-control" value={name} onChange={(e)=>{setName(e.target.value)}}  />

<label>age</label>
<input type="number" className="form-control" value={age} onChange={(e)=>{setAge(e.target.value)}} />
<label>place</label>
<input type="text" className="form-control" value={place} onChange={(e)=>{setPlace(e.target.value)}} />
<label>Change password</label>
<input type="text" className="form-control" value={password} onChange={(e)=>{setPassword(e.target.value)}}/>

<button type="submit" className="form-control btn btn-primary mb-2 mt-2">Update</button>
</form>

</div>
<div className="col-md-4"></div>
</div>
</section>
        </>
     );
}

export default Profile;