import { useContext, useState } from "react";
import Home from "./Home";
import Login from "./Login";
import Reg from "./Reg";
import { BrowserRouter as Router,Routes,Route } from "react-router-dom";
import { Contextapi } from "./Contextapi";
import Profile from "./Profile";
import Location from "./Location";

function App() {
  const [name,setName]=useState(window.localStorage.getItem('name'))
  return (
    <>
    <Router>
      <Contextapi.Provider value={{name,setName}}>

      <Routes>
        <Route path="/reg" element={<Reg/>}></Route>
        <Route path="/" element={<Login/>}></Route>
        <Route path="/home" element={<Home/>}></Route>
        <Route path="/profile" element={<Profile/>}></Route>
        <Route path="/location" element={<Location/>}></Route>
      </Routes>
      </Contextapi.Provider>

    </Router>
    </>
    );
}

export default App;