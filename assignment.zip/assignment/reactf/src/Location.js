import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Contextapi } from "./Contextapi";


function Location() {
    const {name,setName}=useContext(Contextapi)
    const navigate=useNavigate()
  const [img,setImg]=useState('')
    function handleimg(e){
        console.log(e.target.files)
        setImg(e.target.files[0])
    }

    function handellogout(e){
        window.localStorage.removeItem('name')
        setName(window.localStorage.getItem('name'))
       navigate('/')
    }
    return ( 
        <>
        <nav className="navbar navbar-expand-lg bg-dark">
  <div className="container-fluid">
    <Link className="navbar-brand" to="#"><span className="text-light">Welcome <b className="text-warning">{name}</b></span></Link>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div className="navbar-nav ms-auto">
      <Link className="nav-link active" aria-current="page" to="/home">Home</Link>
        <Link className="nav-link active" aria-current="page" to="/profile">Profile Update</Link>
        <Link className="nav-link active" aria-current="page" to="">Location</Link>
        
        <Link className="nav-link" to="/"><button className="btn btn-danger" onClick={(e)=>{handellogout(e)}}>Logout</button></Link>
       
       
      </div>
    </div>
  </div>
</nav>
<div id="location">
    <div className="container">
        <div className="row">
        <div className="col-md-4"></div>
       
            <div className="col-md-4"> 
            <h2>Upload Location</h2>
             <form>
       <input type="file" onChange={(e)=>{handleimg(e)}}  className="form-control" placeholder="Upload Location img"/>
       <input type="text" className="form-control mt-2 mb-2"  placeholder="location Deatails"/>
       <button className="btn btn-primary form-control mt-2">Upload</button>
   </form></div>
            <div className="col-md-4"></div>
        </div>
    </div>
</div>
 

        </>
     );
}

export default Location;