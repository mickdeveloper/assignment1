const mongoose=require('mongoose')

const regSchema=mongoose.Schema({
    name:String,
    age:Number,
    place:String,
    password:String,
    image:String
})

module.exports=mongoose.model('reg',regSchema)