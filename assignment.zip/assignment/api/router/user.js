const router=require('express').Router()
const Reg=require('../models/reg')

router.post('/reg',async(req,res)=>{
    const {name,age,place,password}=req.body
    //console.log(req.body)
    const check=await Reg.findOne({name:name})
    // console.log(check)
    try{
        if(check==null){
            const record=new Reg({name:name,age:age,place:place,password:password})
        record.save()
        res.json({
            apiData:record,
            message:'succesfully register'
        })
        }else{
            res.json({
                status:400,
                message:"username already taken pls try another"
            })
        }
        
    }catch(error){
        res.json({
            message:error.message,
            status:400
        })
    }
})

router.post('/',async(req,res)=>{
    const {name,password}=req.body
    try{
    const usercheck=await Reg.findOne({name:name})
    if(usercheck!==null){
        if(usercheck.password==password){
            res.json({
                status:200,
                message:'login succesfully',
                apiData:usercheck
            })
        }else{
            res.json({
                message:'wrong credantials'
            })
        }
    }else{
        res.json({
            message:'wrong credantials'
        })
    }
}catch(error){
    res.json({
        message:error.message
    })
}
})

router.get('/showalluser',async(req,res)=>{
    try{
          const record= await Reg.find()
          res.json({
            status:200,
            apiData:record
          })

    }catch(error)
    {
        res.json({
            status:500
            })
     }  

    })


router.get('/singleuserdata/:id',(req,res)=>{
    console.log(req.params.id)
    console.log(req.body)
    
})


// router.put('/profileupdate/:id',(req,res)=>{
//     console.log(req.params.id)
//     console.log(req.body)
// })

module.exports=router