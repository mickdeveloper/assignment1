const express=require('express')
const app=express()
app.use(express.json())
const userRouter=require('./router/user')
const mongoose=require('mongoose')
mongoose.connect('mongodb://127.0.0.1:27017/assing')

app.use('/api',userRouter)
app.listen(5000,()=>{console.log('server is running on port 5000')})
